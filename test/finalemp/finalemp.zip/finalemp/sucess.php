<?php
//start a new session

session_start();

$page_title = "Add details";


require_once 'includes/database.php';

// If upload button is clicked ...
if (isset($_POST['upload'])) {

  $id = $_POST['id'];
  $name = $_POST['name'];
  $whatsapp = $_POST['whatsapp'];
  $map = $_POST['map'];
  $email = $_POST['email'];
  $address = $_POST['address'];
  $website = $_POST['website'];
  $facebook = $_POST['facebook'];
  $twitter = $_POST['twitter'];
  $instagram = $_POST['instagram'];
  $youtube = $_POST['youtube'];
  $pinterest = $_POST['pinterest'];
  $linked = $_POST['linked'];
  $telegram = $_POST['telegram'];

  $filename = $_FILES["photo"]["name"];
  $tempname = $_FILES["photo"]["tmp_name"];
  $folder = "./image/" . $filename;



  // Get all the submitted data from the form
  $sql = "INSERT INTO emp VALUES ('$id','$name', '$whatsapp', '$map', '$email', '$address','$website','$facebook','$twitter','$instagram','$youtube','$pinterest','$linked','$telegram','$filename')";

  // Execute query
  $RESULT = @$conn->query($sql);

  // Now let's move the uploaded image into the folder: image
  if (move_uploaded_file($tempname, $folder)) 
  {
  		echo '

        <!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.4.1/dist/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">

    <title>Sucesss</title>
    <style>
    .success{
        text-align:center;
        width:"200px" ;
        height:"200px";
 background: none;
    }
    h1{
        color:green;
    }
    h4{
        color:black;
    }
</style>
  </head>
  <body>
  <body>
<div class="container">
<div class="row-12">
<div class="success">
<h1>  uploaded successfully!</h1>
<img src="success.png">
<h5>Verification Process Started</h5><h4>Thank You For Submit Your Details</h4></div></div>
</div>

    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.4.1/dist/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>
  </body>
</html>
      
        
       ';
	} else {
		echo "<h3> Failed to upload image!</h3>";
	}
}
?>